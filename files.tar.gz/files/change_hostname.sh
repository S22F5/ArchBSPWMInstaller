#!/bin/sh
NEW_HOSTNAME=$(shuf -n 1 /etc/hostnames)
echo "$NEW_HOSTNAME" > /etc/hostname
sed -i 's/127.0.1.1.*/127.0.1.1 "$NEW_HOSTNAME"/' /etc/hosts

for interface in /sys/class/net/*/
do
  macchanger -r "$(basename "$interface")"
  echo "$interface"
done